# RG2021_projects

This repository houses the games for the final project of the lecture Robotic Games.
The games are implemented using the [rogata_engine](https://rogata-engine.readthedocs.io/en/latest/what_is_rogata.html) which can be installed by following the tutorials [here](https://rogata-engine.readthedocs.io/en/latest/usage.html)
